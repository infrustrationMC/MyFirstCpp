﻿#include "lib.h"
#include <stdio.h>
using namespace std;

#define _MAX_CHAR_ARR_ 1000
#if 0
int main()
{
	cout << "a";
}
#endif

#pragma region MyRegion
#if 0
#include <io.h>
#include <fcntl.h>
int main()
{
	wstring ws = L"Lê Văn Luyện";
	//string s = "Lê Văn Luyện";
	wcout << ws << "\n";
	//cout << s;
}
#endif // I'm Vietnamese
#pragma endregion

#if 0
int main()
{
	int int_[10][10][10];
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			for (int k = 0; k < 10; k++)
			{
				int_[i + 1][j + 1][k + 1] = (i + 1)*(j + 1)*(k + 1);
			}
		}
	}
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 10; j++)
		{
			for (int k = 0; k < 10; k++)
			{
				printf("int_[%d][%d][%d] = %d\t\t", i + 1, j + 1, k + 1, int_[i + 1][j + 1][k + 1]);
			}
		}
	}
	return 0;
}
#endif dscc

#if 0
int main()
{
	int a, b;
	cout << "Nhap a: ";
	cin >> a;
	cout << "Nhap b: ";
	cin >> b;
}
#endif // 1

//$a + $b;
// Tinh tong cua a va b
//$

/*
davdgvasgdagda asdh asdajdajdv

*/