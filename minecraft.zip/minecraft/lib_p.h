#ifndef _lib_p_
#define _lib_p_
#include "str.h"
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_NONSTDC_NO_DEPRECATE
#define _MAX_CHAR_ARR_ 1000
#endif _lib_p_
