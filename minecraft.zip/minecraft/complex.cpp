//SO PHUC
#include "lib.h"
#include "complex.h"
using namespace std;
#if 0
int main()
{
	complex cmp;
	cmp.c_out(2.54, 5.32);
	return 0;
}
#endif 0